# REDYA Android — versión limpia

Proyecto Android de REDYA/MascotaDatos, preparado para compilar en GitHub Actions.

- Paquete: `cl.mascotadatos.app`
- Android API 36
- Java 17
- Gradle 8.13 / Android Gradle Plugin 8.11.1
- WebView con WebViewAssetLoader
- Carga la aplicación web incluida en `app/src/main/assets/`
- Selector de archivos/fotografías para formularios web
- Botón Atrás del sistema compatible con navegación WebView
- Internet habilitado para Supabase y recursos HTTPS

El backend Supabase y la configuración web existente se conservan en la página incluida.
