
function show(id){
 document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
 document.getElementById(id).classList.add('active');
 document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===id));
 scrollTo({top:0,behavior:'smooth'});
}
function filterItems(q,id){
 q=q.toLowerCase().trim();
 document.querySelectorAll('#'+id+' .item').forEach(el=>{
   el.style.display=!q || (el.dataset.search||'').includes(q) ? 'block':'none';
 });
}

const cityData = {
copiapo:[
["Hospital Clínico Veterinario Huellitas","Callejón José Joaquín Vallejo 630","+56 52 223 3133 / +56 9 7444 4971"],
["Clínica Veterinaria Los Pimientos","Los Carrera 1267/1268 A","(52) 223 6811 / +56 9 6437 1399"],
["Hospital Clínico Veterinario Incavet Copiapó","El Inca 440","+56 9 9523 7407"],
["Clínica Veterinaria Mc Kotta","Bernardo O'Higgins 815","+56 9 9699 4699"],
["CEMEVET","Bernardo O'Higgins 1253","+56 55 292 0792"]
],
caldera:[
["Veterinaria Caldera","Batallón de Atacama 715","+56 9 7988 3323"],
["Clínica Veterinaria VETERTECH Atacama","Av. Diego de Almeyda 112","+56 9 8449 4971"]
],
vallenar:[
["Clínica Veterinaria Smartpet","Alonso de Ercilla 390","+56 51 261 4990"],
["Centro Veterinario Vallenar","Arturo Prat 1595","+56 51 261 3149"],
["Vaterinaria Petland Cavancha","Vallenar","Por verificar"]
],
chanaral:[
["Clínica Veterinaria MiVet","Conchuela 367, B","+56 9 6473 4880"],
["Veterinario Online Lautovet","Flamenco s/n","+56 9 5679 3085"],
["Veterinaria Municipal de Chañaral","Domeyko","Por verificar"],
["Consulta Veterinaria Safivet","Chañaral","+56 9 8544 8903"]
],
huasco:[
["Veterinaria Praga","Pje. Astillero 147","+56 9 7575 3796"]
],
freirina:[
["Atención de Veterinaria Municipal","Latorre, Freirina","Por verificar"]
],
diego:[
],
tierra:[],
alto:[]
};
async function city(id){
 const names={copiapo:"Copiapó",caldera:"Caldera",vallenar:"Vallenar",chanaral:"Chañaral",huasco:"Huasco",freirina:"Freirina",diego:"Diego de Almagro",tierra:"Tierra Amarilla",alto:"Alto del Carmen"};
 const cityName=names[id];
 const box=document.getElementById('cityContent');
 box.innerHTML='<h2>📍 '+esc(cityName)+'</h2><div class="notice">⏳ Actualizando información desde la base online…</div>';
 try{
   const {data,error}=await sb.from('businesses').select('id,name,address,phone,category,verification_status,updated_at,cities(name)').eq('cities.name',cityName).order('name');
   if(error) throw error;
   const list=(data||[]).filter(x=>(x.category||'').toLowerCase()==='veterinaria');
   let h='<h2>📍 '+esc(cityName)+'</h2>';
   if(!list.length){
     const fallback=cityData[id]||[];
     if(!fallback.length){h+='<div class="notice">Todavía no hay una ficha veterinaria local confirmada para esta ciudad.</div>';}
     else {h+='<div class="notice">No hay fichas veterinarias en la base online todavía. Mostrando la información local disponible como respaldo.</div><div class="list">'+fallback.map(x=>{const verify=x[2].toLowerCase().includes('verificar');return '<div class="item"><div class="top"><h3>'+esc(x[0])+'</h3><span class="badge '+(verify?'warn':'')+'">'+(verify?'Por verificar':'Ficha pública')+'</span></div><div class="meta">📍 '+esc(x[1])+'<br>📞 '+esc(x[2])+'<br><button class="btn" style="margin-top:8px" onclick="openMap('+JSON.stringify(x[1]+', '+cityName+', Atacama, Chile')+')">📍 Ver ubicación</button></div></div>';}).join('')+'</div>';}
   } else {
     h+='<div class="notice">☁️ Información actualizada desde MascotaDatos.</div><div class="list">'+list.map(x=>'<div class="item"><div class="top"><h3>'+esc(x.name)+'</h3><span class="badge '+(x.verification_status==='verificado'?'':'warn')+'">'+(x.verification_status==='verificado'?'Verificado':'Por verificar')+'</span></div><div class="meta">📍 '+esc(x.address||'Dirección no indicada')+'<br>📞 '+esc(x.phone||'Por verificar')+'<br><button class="btn" style="margin-top:8px" onclick="openMap('+JSON.stringify((x.address||'')+', '+cityName+', Atacama, Chile')+')">📍 Ver ubicación</button> <button class="btn" style="margin-top:8px" onclick="openReviews('+Number(x.id)+','+JSON.stringify(x.name||'Negocio')+')">⭐ Opiniones</button></div></div>').join('')+'</div>';
   }
   box.innerHTML=h;
 }catch(err){
   const list=cityData[id]||[];
   let h='<h2>📍 '+esc(cityName)+'</h2><div class="notice">⚠️ No se pudo actualizar la base online. Mostrando la información disponible en la aplicación.</div>';
   if(list.length) h+='<div class="list">'+list.map(x=>'<div class="item"><div class="top"><h3>'+esc(x[0])+'</h3><span class="badge">Ficha pública</span></div><div class="meta">📍 '+esc(x[1])+'<br>📞 '+esc(x[2])+'</div></div>').join('')+'</div>';
   box.innerHTML=h;
 }
}
function openMap(q){ window.open('https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(q),'_blank'); }


const shops = [{"ciudad": "Copiapó", "nombre": "Ciudad Mascota", "direccion": "Los Carrera 1036, Copiapó", "telefono": "+56 9 5215 0987", "categoria": "Pet shop", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "FarmVet Los Mancos O'Higgins 21", "direccion": "Bernardo O'Higgins 21, Copiapó", "telefono": "+56 9 5830 0433", "categoria": "Farmacia veterinaria", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "Tienda de mascotas Betta", "direccion": "Bernardo O'Higgins 397, Copiapó", "categoria": "Pet shop", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "Mascotas Copiapó", "direccion": "Manuel Antonio Caro 4179, Copiapó", "categoria": "Tienda de mascotas", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "Maskolandia", "direccion": "Los Loros 1335, Copiapó", "telefono": "+56 9 7466 3039", "categoria": "Pet shop", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "MATANDA PET", "direccion": "Los Carrera 2354, Copiapó", "telefono": "+56 9 5664 1895", "categoria": "Alimentos y accesorios", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "Petshop Lissette", "direccion": "Sur 1389, El Palomar, Copiapó", "telefono": "+56 9 5906 5061", "categoria": "Pet shop", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "Peces Aqua Fish Copiapó", "direccion": "Pje. Padre Liborio 5842, Copiapó", "categoria": "Peces y acuarios", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "Emporio Animal", "direccion": "Dulcinea 943, Copiapó", "categoria": "Alimentos para animales", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "DISTRITO ANIMAL", "direccion": "Ruta 5 KM 812, Copiapó", "telefono": "+56 9 4572 6784", "categoria": "Productos para mascotas", "estado": "fuente_estructurada"}, {"ciudad": "Copiapó", "nombre": "Yapo Pet Food", "direccion": "Av. Henríquez 627, Palomar, Local 22, Copiapó", "telefono": "+56 9 8541 0035", "categoria": "Alimentos", "estado": "fuente_publica"}, {"ciudad": "Copiapó", "nombre": "Patitas Atacama", "direccion": "Parcela 39-C, Lote 10, Piedra Colgada Norte, Copiapó", "telefono": "+56 9 9151 3063", "categoria": "Productos para mascotas", "estado": "fuente_publica"}, {"ciudad": "Copiapó", "nombre": "Panchitas Pet Shop", "direccion": "La Cruz 678, Copiapó", "telefono": "+56 9 2078 3151", "categoria": "Pet shop", "estado": "fuente_publica"}, {"ciudad": "Copiapó", "nombre": "La casa de Mini", "direccion": "Pedro de Valdivia N°3389, Copiapó", "telefono": "+56 9 3909 6648", "categoria": "Farmacia veterinaria", "estado": "fuente_estructurada"}, {"ciudad": "Caldera", "nombre": "Sammy's Happy Pets", "direccion": "Juan Martínez 274, Caldera", "telefono": "+56 9 5772 0066", "categoria": "Pet shop/mascotas", "estado": "fuente_publica"}, {"ciudad": "Vallenar", "nombre": "Petland", "direccion": "Hacienda Cavancha Parcela F2, Vallenar", "telefono": "+56 9 8378 4608", "categoria": "Centro veterinario/pet", "estado": "fuente_publica"}, {"ciudad": "Vallenar", "nombre": "Centro Veterinario Renacer Pets", "direccion": "Faez 1016, Vallenar", "categoria": "Centro veterinario", "estado": "fuente_publica"}, {"ciudad": "Chañaral", "nombre": "Pet Dog Cat", "direccion": "Pasaje General Bonilla 359, Chañaral", "telefono": "+56 9 4869 0247", "categoria": "Pet shop", "estado": "fuente_publica"}, {"ciudad": "Chañaral", "nombre": "Animal Shopping", "direccion": "Zuleta 240, Chañaral", "telefono": "+56 9 9336 8841", "categoria": "Tienda de mascotas", "estado": "fuente_publica"}, {"ciudad": "El Salvador", "nombre": "Safivet", "direccion": "Av. El Tofo 047 E, local 2, El Salvador", "categoria": "Veterinaria/insumos", "estado": "fuente_publica"}, {"ciudad": "Huasco", "nombre": "Mauricio Carrillo Vidal", "direccion": "Riquelme 153, Huasco", "telefono": "+56 9 9302 4982", "categoria": "Servicio para mascotas", "estado": "fuente_publica"}];
async function loadShops(city){
  const box=document.getElementById('shopResults');
  box.innerHTML='<h2>📍 '+esc(city)+'</h2><div class="notice">⏳ Actualizando información desde la base online…</div>';
  try{
    const {data,error}=await sb.from('businesses').select('id,name,address,phone,category,verification_status,updated_at,cities(name)').eq('cities.name',city).order('name');
    if(error) throw error;
    const list=(data||[]).filter(x=>(x.category||'').toLowerCase()!=='veterinaria');
    let h='<h2>📍 '+esc(city)+'</h2>';
    if(!list.length){h+='<div class="notice">Todavía no hay locales o servicios registrados en la base online para esta ciudad.</div>';}
    else {h+='<div class="notice">☁️ Información actualizada desde MascotaDatos.</div><div class="list">'+list.map(x=>'<div class="item"><div class="top"><h3>'+esc(x.name)+'</h3><span class="badge">'+esc(x.category||'Servicio')+'</span></div><div class="meta">📍 '+esc(x.address||'Dirección no indicada')+'<br>📞 '+esc(x.phone||'Por verificar')+'<br><button class="btn" style="margin-top:8px" onclick="openMap('+JSON.stringify((x.address||'')+', '+city+', Atacama, Chile')+')">📍 Ver ubicación</button> <button class="btn" style="margin-top:8px" onclick="openReviews('+Number(x.id)+','+JSON.stringify(x.name||'Negocio')+')">⭐ Opiniones</button></div></div>').join('')+'</div>';}
    box.innerHTML=h;
  }catch(err){
    const list=shops.filter(x=>x.ciudad===city);
    let h='<h2>📍 '+esc(city)+'</h2><div class="notice">⚠️ No se pudo actualizar la base online. Mostrando la información disponible en la aplicación.</div>';
    if(list.length) h+='<div class="list">'+list.map(x=>'<div class="item"><div class="top"><h3>'+esc(x.nombre)+'</h3><span class="badge">'+esc(x.categoria)+'</span></div><div class="meta">📍 '+esc(x.direccion)+'<br>📞 '+esc(x.telefono||'Por verificar')+'</div></div>').join('')+'</div>';
    box.innerHTML=h;
  }
}


const globalData = [{"tipo": "Veterinaria", "nombre": "Hospital Clínico Veterinario Huellitas", "direccion": "Callejón José Joaquín Vallejo 630, Copiapó", "telefono": "+56 52 223 3133 / +56 9 7444 4971", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Veterinaria Copiapó Ltda.", "direccion": "Av. Henríquez 252, Copiapó", "telefono": "+56 55 296 8704", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Hospital Clínico Veterinario Incavet Copiapó", "direccion": "El Inca 440, Copiapó", "telefono": "+56 9 9523 7407", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Clínica Veterinaria Asis", "direccion": "Miguel Gallo 923, Copiapó", "telefono": "+56 52 221 5180", "estado": "por_verificar"}, {"tipo": "Veterinaria", "nombre": "Clínica Veterinaria Los Pimientos", "direccion": "Los Carrera 1267/1268 A, Copiapó", "telefono": "+56 52 223 6811", "estado": "por_verificar"}, {"tipo": "Veterinaria", "nombre": "Unidad Veterinaria Municipal de Copiapó", "direccion": "Atacama 1049, Copiapó", "telefono": "+56 9 7616 2582 / +56 9 8922 0084", "estado": "por_verificar"}, {"tipo": "Veterinaria", "nombre": "Clínica Veterinaria Mc Kotta", "direccion": "Bernardo O'Higgins 815, Copiapó", "telefono": "+56 9 9699 4699", "estado": "verificado_fuente_oficial"}, {"tipo": "Veterinaria", "nombre": "CEMEVET", "direccion": "Bernardo O'Higgins 1253, Copiapó", "telefono": "+56 55 292 0792", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Clínica Veterinaria Auravet SPA", "direccion": "Bernardo O'Higgins 991, Copiapó", "telefono": "+56 9 5702 3723", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Consulta Veterinaria Dr. Ricardo Veliz G.", "direccion": "Juan Martínez 111, Copiapó", "telefono": "+56 9 9421 0258", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Centro Quirúrgico Veterinario CEQVET", "direccion": "Luis Flores 483, Copiapó", "telefono": "+56 9 7644 8018", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Munay Vet — Clínica Veterinaria", "direccion": "Av. Ignacio Carrera Pinto 743, Copiapó", "telefono": "+56 9 7374 6914", "estado": "verificado_fuente_oficial"}, {"tipo": "Veterinaria", "nombre": "PAGAROMA PET", "direccion": "Ingreso por Circunvalación, San Antonio 3167, Copiapó", "telefono": "+56 9 9313 2939", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Juan Pedro Silva Moya — consulta/profesional", "direccion": "Hugo Bordoli 1355, Copiapó", "telefono": "+56 52 224 1057", "estado": "publicado"}, {"tipo": "Veterinaria", "nombre": "Santa María Clínica Veterinaria", "direccion": "Bernardo O'Higgins 991, Copiapó", "telefono": "", "estado": "por_verificar"}, {"tipo": "Pet shop", "nombre": "Ciudad Mascota", "direccion": "Los Carrera 1036, Copiapó", "telefono": "+56 9 5215 0987", "estado": "fuente_estructurada"}, {"tipo": "Farmacia veterinaria", "nombre": "FarmVet Los Mancos O'Higgins 21", "direccion": "Bernardo O'Higgins 21, Copiapó", "telefono": "+56 9 5830 0433", "estado": "fuente_estructurada"}, {"tipo": "Pet shop", "nombre": "Tienda de mascotas Betta", "direccion": "Bernardo O'Higgins 397, Copiapó", "telefono": "", "estado": "fuente_estructurada"}, {"tipo": "Tienda de mascotas", "nombre": "Mascotas Copiapó", "direccion": "Manuel Antonio Caro 4179, Copiapó", "telefono": "", "estado": "fuente_estructurada"}, {"tipo": "Pet shop", "nombre": "Maskolandia", "direccion": "Los Loros 1335, Copiapó", "telefono": "+56 9 7466 3039", "estado": "fuente_estructurada"}, {"tipo": "Alimentos y accesorios", "nombre": "MATANDA PET", "direccion": "Los Carrera 2354, Copiapó", "telefono": "+56 9 5664 1895", "estado": "fuente_estructurada"}, {"tipo": "Pet shop", "nombre": "Petshop Lissette", "direccion": "Sur 1389, El Palomar, Copiapó", "telefono": "+56 9 5906 5061", "estado": "fuente_estructurada"}, {"tipo": "Peces y acuarios", "nombre": "Peces Aqua Fish Copiapó", "direccion": "Pje. Padre Liborio 5842, Copiapó", "telefono": "", "estado": "fuente_estructurada"}, {"tipo": "Alimentos para animales", "nombre": "Emporio Animal", "direccion": "Dulcinea 943, Copiapó", "telefono": "", "estado": "fuente_estructurada"}, {"tipo": "Productos para mascotas", "nombre": "DISTRITO ANIMAL", "direccion": "Ruta 5 KM 812, Copiapó", "telefono": "+56 9 4572 6784", "estado": "fuente_estructurada"}, {"tipo": "Alimentos", "nombre": "Yapo Pet Food", "direccion": "Av. Henríquez 627, Palomar, Local 22, Copiapó", "telefono": "+56 9 8541 0035", "estado": "fuente_publica"}, {"tipo": "Productos para mascotas", "nombre": "Patitas Atacama", "direccion": "Parcela 39-C, Lote 10, Piedra Colgada Norte, Copiapó", "telefono": "+56 9 9151 3063", "estado": "fuente_publica"}, {"tipo": "Pet shop", "nombre": "Panchitas Pet Shop", "direccion": "La Cruz 678, Copiapó", "telefono": "+56 9 2078 3151", "estado": "fuente_publica"}, {"tipo": "Farmacia veterinaria", "nombre": "La casa de Mini", "direccion": "Pedro de Valdivia N°3389, Copiapó", "telefono": "+56 9 3909 6648", "estado": "fuente_estructurada"}, {"tipo": "Pet shop/mascotas", "nombre": "Sammy's Happy Pets", "direccion": "Juan Martínez 274, Caldera", "telefono": "+56 9 5772 0066", "estado": "fuente_publica"}, {"tipo": "Centro veterinario/pet", "nombre": "Petland", "direccion": "Hacienda Cavancha Parcela F2, Vallenar", "telefono": "+56 9 8378 4608", "estado": "fuente_publica"}, {"tipo": "Centro veterinario", "nombre": "Centro Veterinario Renacer Pets", "direccion": "Faez 1016, Vallenar", "telefono": "", "estado": "fuente_publica"}, {"tipo": "Pet shop", "nombre": "Pet Dog Cat", "direccion": "Pasaje General Bonilla 359, Chañaral", "telefono": "+56 9 4869 0247", "estado": "fuente_publica"}, {"tipo": "Tienda de mascotas", "nombre": "Animal Shopping", "direccion": "Zuleta 240, Chañaral", "telefono": "+56 9 9336 8841", "estado": "fuente_publica"}, {"tipo": "Veterinaria/insumos", "nombre": "Safivet", "direccion": "Av. El Tofo 047 E, local 2, El Salvador", "telefono": "", "estado": "fuente_publica"}, {"tipo": "Servicio para mascotas", "nombre": "Mauricio Carrillo Vidal", "direccion": "Riquelme 153, Huasco", "telefono": "+56 9 9302 4982", "estado": "fuente_publica"}];
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function doGlobalSearch(){
  const q=(document.getElementById('globalSearch').value||'').toLowerCase().trim();
  const box=document.getElementById('globalResults');
  if(!q){box.innerHTML='<div class="notice">Escribe algo para comenzar la búsqueda.</div>';return;}
  const hits=globalData.filter(x=>(x.nombre+' '+x.direccion+' '+x.tipo).toLowerCase().includes(q)).slice(0,30);
  if(!hits.length){box.innerHTML='<div class="notice">No encontramos una ficha con esa búsqueda todavía.</div>';return;}
  box.innerHTML=hits.map(x=>'<div class="item"><div class="top"><h3>'+esc(x.nombre)+'</h3><span class="badge">'+esc(x.tipo)+'</span></div><div class="meta">📍 '+esc(x.direccion)+'<br>📞 '+esc(x.telefono||'Por verificar')+'<br>Estado: '+esc(x.estado||'Por verificar')+'<br><button class="btn" style="margin-top:8px" onclick="openMap('+JSON.stringify(x.direccion)+')">📍 Ver ubicación</button></div></div>').join('');
}


async function getCityIdByForm(form){
  const id=form.querySelector('[name="city_id"]')?.value;
  return id ? Number(id) : null;
}
async function uploadPetPhoto(file,userId){
  if(!file)return null;
  if(file.size>5*1024*1024) throw new Error('La foto supera el límite de 5 MB.');
  const ext=(file.name.split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'');
  const path=userId+'/'+crypto.randomUUID()+'.'+ext;
  const {error}=await sb.storage.from('pet-photos').upload(path,file,{contentType:file.type,upsert:false});
  if(error)throw error;
  return path;
}
async function requireVerifiedEmail(user,msg){
  if(!user){msg.textContent='ℹ️ Primero crea una cuenta o inicia sesión en Mi cuenta.';return false;}
  if(!user.email){msg.textContent='❌ Tu cuenta no tiene un correo asociado.';return false;}
  if(!user.email_confirmed_at){msg.innerHTML='🔐 Para publicar avisos necesitas <b>confirmar tu correo electrónico</b>. Revisa tu bandeja de entrada y luego vuelve a intentarlo.';return false;}
  return true;
}

async function savePost(e,type){
  e.preventDefault();
  const form=e.target;
  const msg=document.getElementById({adopcion:'draftAdopcion',perdida:'draftPerdida',encontrada:'draftEncontrada'}[type]);
  msg.style.display='block'; msg.textContent='⏳ Guardando aviso…';
  const {data:{user}}=await sb.auth.getUser();
  if(!(await requireVerifiedEmail(user,msg))) return;
  try{
    const fd=new FormData(form);
    const cityId=await getCityIdByForm(form);
    const file=fd.get('photo');
    const photoPath=await uploadPetPhoto(file,user.id);
    const payload={user_id:user.id,post_type:type,pet_type:fd.get('pet_type'),name:fd.get('name')||null,city_id:cityId,sector:fd.get('sector')||null,description:fd.get('description'),event_date:fd.get('event_date')||null,photo_url:photoPath,contact_method:fd.get('contact_method'),status:'pendiente'};
    const {error}=await sb.from('pet_posts').insert(payload);
    if(error){
      if(photoPath) await sb.storage.from('pet-photos').remove([photoPath]);
      throw error;
    }
    msg.innerHTML='✅ Aviso enviado correctamente.<br><small>Quedó <b>pendiente de revisión</b>. No será público hasta ser aprobado.</small>';
    form.reset();
  }catch(err){msg.textContent='❌ '+(err?.message||'No se pudo guardar el aviso.');}
}
async function getPublishedPhotoUrl(postId){
  try{
    const r=await fetch(SUPABASE_URL+'/functions/v1/published_pet_photo?post_id='+encodeURIComponent(postId));
    const text=await r.text();
    let j={}; try{j=JSON.parse(text)}catch(_){return null;}
    if(!r.ok || !j.url)return null;
    return j.url;
  }catch(_){return null;}
}
async function loadPublishedPhoto(postId,imgId,placeholderId){
  const img=document.getElementById(imgId), ph=document.getElementById(placeholderId);
  const url=await getPublishedPhotoUrl(postId);
  if(url && img){img.src=url;img.style.display='block';if(ph)ph.style.display='none';}
  else if(ph){ph.textContent='📷 Fotografía no disponible';}
}
async function loadPublicPosts(type){
  const box=document.getElementById(type==='adopcion'?'adoptionResults':'lostResults');
  show(type==='adopcion'?'adopcion2':'perdidos2');
  box.innerHTML='<div class="notice">⏳ Cargando avisos…</div>';
  const {data,error}=await sb.from('pet_posts').select('id,post_type,pet_type,name,sector,description,event_date,photo_url,created_at,city_id,cities(name)').eq('status','publicada').eq('post_type',type).order('created_at',{ascending:false}).limit(50);
  if(error){box.innerHTML='<div class="notice">⚠️ No se pudieron cargar los avisos.</div>';return;}
  if(!data?.length){box.innerHTML='<div class="notice">Todavía no hay avisos publicados en esta categoría.</div>';return;}
  const likeCounts=await getLikeCounts(data.map(x=>Number(x.id)));
  const sessionResult=await sb.auth.getSession();
  const currentUser=sessionResult.data?.session?.user||null;
  const myLikes=currentUser?await getMyLikes(data.map(x=>Number(x.id)),currentUser.id):new Set();
  box.innerHTML=data.map((x,i)=>{const id=Number(x.id);const imgId='pubimg_'+type+'_'+i;const phId='pubph_'+type+'_'+i;const count=likeCounts[id]||0;const liked=myLikes.has(id);return '<div class="item"><div class="top"><h3>'+esc(x.name||x.pet_type||'Mascota')+'</h3><span class="badge">'+esc(x.pet_type||'Mascota')+'</span></div><div style="margin-top:9px"><div id="'+phId+'" class="notice">⏳ Cargando fotografía…</div><img id="'+imgId+'" alt="Fotografía de mascota publicada" style="display:none;width:100%;max-height:260px;object-fit:cover;border-radius:12px;margin-top:8px"></div><div class="meta">📍 '+esc(x.cities?.name||'Ciudad no indicada')+(x.sector?' · '+esc(x.sector):'')+'<br>'+esc(x.description)+(x.event_date?'<br>📅 '+esc(x.event_date):'')+'<br><button class="btn" style="margin-top:8px" onclick="toggleLike('+id+',this)" data-liked="'+(liked?'1':'0')+'">'+(liked?'❤️':'🤍')+' Me gusta <span class="likeCount">'+count+'</span></button> <button class="btn" style="margin-top:8px" onclick="showReportFor('+id+')">🚩 Reportar</button></div></div>';}).join('');
  data.forEach((x,i)=>loadPublishedPhoto(Number(x.id),'pubimg_'+type+'_'+i,'pubph_'+type+'_'+i));
}
async function getLikeCounts(ids){
  if(!ids.length)return {};
  const {data}=await sb.from('pet_post_likes').select('post_id').in('post_id',ids);
  const counts={};
  (data||[]).forEach(x=>{const id=Number(x.post_id);counts[id]=(counts[id]||0)+1;});
  return counts;
}
async function getMyLikes(ids,userId){
  if(!ids.length)return new Set();
  const {data}=await sb.from('pet_post_likes').select('post_id').eq('user_id',userId).in('post_id',ids);
  return new Set((data||[]).map(x=>Number(x.post_id)));
}
async function toggleLike(id,button){
  const {data:{user}}=await sb.auth.getUser();
  if(!user){alert('Debes iniciar sesión para dar Me gusta.');return;}
  const liked=button.dataset.liked==='1';
  button.disabled=true;
  let error;
  if(liked){({error}=await sb.from('pet_post_likes').delete().eq('post_id',id).eq('user_id',user.id));}
  else{({error}=await sb.from('pet_post_likes').insert({post_id:id,user_id:user.id}));}
  if(error){alert('No se pudo actualizar el Me gusta.');button.disabled=false;return;}
  button.dataset.liked=liked?'0':'1';
  button.innerHTML=(liked?'🤍':'❤️')+' Me gusta <span class="likeCount">'+(Math.max(0,Number(button.querySelector('.likeCount')?.textContent||0)+(liked?-1:1)))+'</span>';
  button.disabled=false;
}

function showReportFor(id){show('reportar');document.querySelector('#reportar [name="post_id"]').value=id;}
async function sendReport(e){
  e.preventDefault(); const form=e.target, msg=document.getElementById('reportMsg'); msg.style.display='block'; msg.textContent='⏳ Enviando reporte…';
  const {data:{user}}=await sb.auth.getUser(); if(!user){msg.textContent='ℹ️ Debes iniciar sesión para reportar una publicación.';return;}
  const fd=new FormData(form);
  const {error}=await sb.from('post_reports').insert({post_id:Number(fd.get('post_id')),reporter_user_id:user.id,reason:fd.get('reason'),details:fd.get('details'),status:'pendiente'});
  if(error){msg.textContent='❌ No se pudo enviar el reporte: '+esc(error.message);return;}
  msg.textContent='✅ Reporte enviado al equipo de moderación.'; form.reset();
}
async function loadModeration(){
  const box=document.getElementById('moderationResults'); if(!box)return; box.innerHTML='<div class="notice">⏳ Comprobando permisos y cargando pendientes…</div>';
  const {data,error}=await sb.from('pet_posts').select('id,post_type,pet_type,name,description,sector,event_date,photo_url,created_at,cities(name),user_id').eq('status','pendiente').order('created_at',{ascending:true}).limit(50);
  if(error){box.innerHTML='<div class="notice">🔒 No tienes permiso para consultar los pendientes o hubo un error de conexión.</div>';return;}
  if(!data?.length){box.innerHTML='<div class="notice">✅ No hay avisos pendientes.</div>';return;}
  box.innerHTML=data.map(x=>'<div class="item"><div class="top"><h3>#'+x.id+' · '+esc(x.name||x.pet_type)+'</h3><span class="badge warn">Pendiente</span></div><div class="meta">'+esc(x.post_type)+' · '+esc(x.pet_type)+' · '+esc(x.cities?.name||'Sin ciudad')+'<br>'+esc(x.description)+(x.sector?' · '+esc(x.sector):'')+(x.event_date?'<br>📅 '+esc(x.event_date):'')+'<div style="margin-top:8px"><button class="btn" onclick="moderatePost('+x.id+',\'publicada\')">✅ Aprobar</button> <button class="btn" onclick="moderatePost('+x.id+',\'rechazada\')">❌ Rechazar</button></div></div></div>').join('');
}
async function moderatePost(id,status){
  const {error}=await sb.from('pet_posts').update({status}).eq('id',id);
  if(error){alert('No se pudo cambiar el estado: '+error.message);return;}
  loadModeration();
  if(window.mascotaSession) loadMyPosts();
}
function fillCitySelects(data){document.querySelectorAll('.citySelect').forEach(sel=>{sel.innerHTML='<option value="">Selecciona una ciudad</option>'+data.map(c=>'<option value="'+c.id+'">'+esc(c.name)+'</option>').join('');});}

function demoAccount(e){e.preventDefault();const x=document.getElementById('accountMsg');x.style.display='block';x.innerHTML='ℹ️ Usa el formulario de Mi cuenta para registrarte o iniciar sesión.';}
function demoReport(e){e.preventDefault();sendReport(e);}



if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('sw.js').catch(()=>{});
}


const SUPABASE_URL='https://dipqxifxrkujvfukcskg.supabase.co';
const SUPABASE_PUBLISHABLE_KEY='sb_publishable_cI2DN3hLz4NxFiWZoEIRig_fYVXcZ4Z';
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY);
sb.auth.onAuthStateChange((event)=>{if(event==='PASSWORD_RECOVERY'){const b=document.getElementById('newPasswordBox');if(b)b.style.display='block';const m=document.getElementById('accountMsg');if(m){m.style.display='block';m.textContent='🔐 Enlace válido. Crea ahora tu nueva contraseña.';}}});
(function(){const q=new URLSearchParams(location.search);if(q.get('type')==='recovery'){const b=document.getElementById('newPasswordBox');if(b)b.style.display='block';}})();

async function checkOnline(){
  const el=document.getElementById('onlineStatus');
  try{
    const {data,error}=await sb.from('cities').select('name').order('name');
    if(error) throw error;
    el.innerHTML='☁️ <b>Conectado</b> a la base online · '+data.length+' ciudades cargadas';
    el.style.display='block';
    window.mascotaCities=data; fillCitySelects(data);
  }catch(e){
    el.innerHTML='⚠️ Sin conexión a la base online en este momento';
  }
}

async function submitBusiness(e){
  e.preventDefault();
  const form=e.target, msg=document.getElementById('businessMsg');
  msg.style.display='block'; msg.textContent='⏳ Enviando solicitud…';
  const {data:{user}}=await sb.auth.getUser();
  if(!user){msg.innerHTML='ℹ️ Para publicar un negocio primero debes <b>crear una cuenta o iniciar sesión</b> en Mi cuenta.';return;}
  if(!user.email_confirmed_at){msg.innerHTML='🔐 Para enviar una solicitud necesitas <b>confirmar tu correo electrónico</b>. Revisa tu bandeja de entrada y luego vuelve a intentarlo.';return;}
  const fd=new FormData(form);
  const payload={
    user_id:user.id, city_id:Number(fd.get('city_id')), name:String(fd.get('name')||'').trim(),
    category:String(fd.get('category')||'').trim(), address:String(fd.get('address')||'').trim()||null,
    phone:String(fd.get('phone')||'').trim()||null, website:String(fd.get('website')||'').trim()||null,
    contact_email:String(fd.get('contact_email')||'').trim()||null, notes:String(fd.get('notes')||'').trim()||null
  };
  if(!payload.city_id){msg.textContent='❌ Selecciona una ciudad.';return;}
  try{
    const {error}=await sb.from('business_submissions').insert(payload);
    if(error) throw error;
    msg.innerHTML='✅ Solicitud enviada correctamente. Quedará <b>pendiente de revisión</b> antes de publicarse.';
    form.reset();
    if(window.mascotaCities) fillCitySelects(window.mascotaCities);
  }catch(err){msg.textContent='❌ No se pudo enviar la solicitud. '+(err.message||'Inténtalo nuevamente.');}
}

async function registerAccount(e){
  e.preventDefault();
  const form=e.target;
  const email=form.querySelector('input[type=email]').value.trim();
  const password=form.querySelector('input[type=password]').value;
  const name=form.querySelector('input[placeholder="Tu nombre"]').value.trim();
  const msg=document.getElementById('accountMsg');
  const {data,error}=await sb.auth.signUp({email,password,options:{data:{full_name:name}}});
  msg.style.display='block';
  if(error){msg.innerHTML='❌ '+esc(error.message);return;}
  msg.innerHTML=data.session ? '✅ Cuenta creada. Si tu correo aparece como pendiente de confirmación, revisa tu bandeja de entrada antes de publicar.' : '✅ Cuenta creada. <b>Confirma tu correo electrónico</b> desde el enlace recibido antes de publicar avisos o negocios.';
  form.reset();
}

function prefillKnownAccount(){
  const e=document.querySelector('input[name=\"email\"]');
  if(e && !e.value) e.value='alttorres@hotmail.com';
}

function showRecovery(){prefillKnownAccount();const b=document.getElementById('recoveryBox');if(b)b.style.display='block';const e=document.querySelector('input[name="email"]'),r=document.getElementById('recovery-email');if(e&&r&&e.value)r.value=e.value;if(r)r.focus();}
function hideRecovery(){const b=document.getElementById('recoveryBox');if(b)b.style.display='none';}
async function requestPasswordReset(e){e.preventDefault();const email=document.getElementById('recovery-email').value.trim(),msg=document.getElementById('accountMsg');msg.style.display='block';msg.textContent='⏳ Enviando enlace de recuperación…';try{const redirectTo=window.location.href.split('#')[0];const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo});if(error)throw error;msg.textContent='✅ Enlace enviado. Revisa tu correo y pulsa el enlace para crear una nueva contraseña.';}catch(err){msg.textContent='❌ '+esc(err.message||String(err));}}
async function updatePassword(e){e.preventDefault();const p1=document.getElementById('new-password-1').value,p2=document.getElementById('new-password-2').value,msg=document.getElementById('accountMsg');msg.style.display='block';if(p1!==p2){msg.textContent='❌ Las contraseñas no coinciden.';return;}msg.textContent='⏳ Guardando nueva contraseña…';const {error}=await sb.auth.updateUser({password:p1});if(error){msg.textContent='❌ '+esc(error.message);return;}msg.textContent='✅ Contraseña actualizada correctamente. Ya puedes iniciar sesión.';document.getElementById('newPasswordBox').style.display='none';}

async function loginAccount(e){
  e.preventDefault();
  const form=e.target, msg=document.getElementById('accountMsg');
  const emailInput=form.querySelector('input[name=\"email\"]');
  const passwordInput=form.querySelector('input[name=\"password\"]');
  const email=(emailInput?.value||'').trim().toLowerCase();
  const password=passwordInput?.value||'';
  msg.style.display='block'; msg.textContent='⏳ Verificando correo y contraseña…';
  if(!email || !password){msg.textContent='❌ Ingresa tu correo y contraseña.';return;}
  try{
    const {data,error}=await sb.auth.signInWithPassword({email,password});
    if(error){
      const m=(error.message||'').toLowerCase();
      if(m.includes('invalid login credentials')){
        msg.innerHTML='❌ El correo existe, pero la contraseña no coincide. Si no recuerdas la contraseña, usa <b>¿Olvidaste tu contraseña?</b> para crear una nueva.';
      }else{msg.textContent='❌ '+esc(error.message||'No se pudo iniciar sesión.');}
      return;
    }
    msg.textContent='✅ Sesión iniciada correctamente.';
    passwordInput.value='';
    updateSessionUI(data.session);
    loadMyPosts();
  }catch(err){msg.textContent='❌ No se pudo conectar con el servicio de acceso. Revisa tu conexión e inténtalo nuevamente.';}
}
async function logoutAccount(){
  const {error}=await sb.auth.signOut();
  const msg=document.getElementById('accountMsg'); msg.style.display='block';
  msg.textContent=error?'❌ '+esc(error.message):'✅ Sesión cerrada.';
  updateSessionUI(null);
}
function updateSessionUI(session){
  window.mascotaSession=session||null;
  const box=document.getElementById('sessionBox'); if(!box)return;
  if(session?.user){
    const email=esc(session.user.email||'');
    box.innerHTML='☁️ <b>Sesión iniciada</b><br>'+email+'<br><button class="btn" style="margin-top:8px" type="button" onclick="logoutAccount()">Cerrar sesión</button>';
  }else{ box.innerHTML='ℹ️ No has iniciado sesión. Necesitas una cuenta para publicar y reportar avisos.'; }
}
async function openReviews(businessId,name){
  show('opiniones');
  document.getElementById('reviewBusinessId').value=businessId;
  document.getElementById('reviewBusiness').innerHTML='<div class="top"><h3>'+esc(name)+'</h3><span class="badge">⭐ Opiniones</span></div><div class="small">Las opiniones publicadas fueron revisadas por MascotaDatos.</div>';
  const box=document.getElementById('reviewList'); box.innerHTML='<div class="notice">⏳ Cargando opiniones…</div>';
  const {data,error}=await sb.from('business_reviews').select('rating,comment,created_at').eq('business_id',businessId).eq('status','aprobada').order('created_at',{ascending:false}).limit(50);
  if(error){box.innerHTML='<div class="notice">⚠️ No se pudieron cargar las opiniones.</div>';return;}
  if(!data?.length){box.innerHTML='<div class="notice">Todavía no hay opiniones aprobadas para este negocio.</div>';return;}
  const avg=(data.reduce((a,x)=>a+Number(x.rating),0)/data.length).toFixed(1);
  box.innerHTML='<div class="notice">⭐ Promedio: <b>'+avg+'/5</b> · '+data.length+' opinión(es)</div>'+data.map(x=>'<div class="item"><div class="top"><h3>'+('⭐'.repeat(Number(x.rating)))+'</h3><span class="small">'+new Date(x.created_at).toLocaleDateString('es-CL')+'</span></div><div class="meta">'+esc(x.comment)+'</div></div>').join('');
}
async function submitBusinessReview(e){
  e.preventDefault();
  const msg=document.getElementById('reviewMsg'); msg.style.display='block'; msg.textContent='⏳ Enviando opinión…';
  const {data:{user}}=await sb.auth.getUser();
  if(!user){msg.textContent='🔐 Debes iniciar sesión para dejar una opinión.';return;}
  if(!user.email_confirmed_at){msg.textContent='📧 Primero debes confirmar tu correo electrónico.';return;}
  const fd=new FormData(e.target);
  const payload={business_id:Number(fd.get('business_id')),user_id:user.id,rating:Number(fd.get('rating')),comment:String(fd.get('comment')||'').trim(),status:'pendiente'};
  const {error}=await sb.from('business_reviews').insert(payload);
  if(error){msg.textContent='❌ '+(error.code==='23505'?'Ya dejaste una opinión para este negocio.':(error.message||'No se pudo enviar la opinión.'));return;}
  msg.textContent='✅ Opinión enviada. Quedó pendiente de revisión antes de publicarse.'; e.target.reset();
}

async function loadMyPosts(){
  const box=document.getElementById('myPosts'); if(!box)return;
  const {data:{user}}=await sb.auth.getUser();
  if(!user){box.innerHTML='<div class="notice">Inicia sesión para ver tus publicaciones.</div>';return;}
  box.innerHTML='<div class="notice">⏳ Cargando tus publicaciones…</div>';
  const {data,error}=await sb.from('pet_posts').select('id,post_type,pet_type,name,status,created_at').eq('user_id',user.id).order('created_at',{ascending:false}).limit(50);
  if(error){box.innerHTML='<div class="notice">⚠️ No se pudieron cargar tus publicaciones.</div>';return;}
  if(!data?.length){box.innerHTML='<div class="notice">Todavía no tienes publicaciones.</div>';return;}
  box.innerHTML=data.map(x=>{const status=x.status||'pendiente'; return '<div class="item"><div class="top"><h3>#'+Number(x.id)+' · '+esc(x.name||x.pet_type||'Mascota')+'</h3><span class="badge">'+esc(status)+'</span></div><div class="meta">'+esc(x.post_type)+' · '+esc(x.pet_type)+'<br><button class="btn" style="margin-top:8px" onclick="deleteMyPost('+Number(x.id)+')">🗑️ Eliminar</button></div></div>';}).join('');
}
async function deleteMyPost(id){
  if(!confirm('¿Eliminar esta publicación?'))return;
  const {error}=await sb.from('pet_posts').delete().eq('id',id);
  if(error){alert('No se pudo eliminar: '+error.message);return;}
  loadMyPosts();
}
async function loadOnlineCities(){
  const box=document.getElementById('cityContent');
  if(!box)return;
  const {data,error}=await sb.from('cities').select('id,name,region').order('name');
  if(error)return;
  box.innerHTML='<h2>🗺️ Ciudades de la Región de Atacama</h2><div class="grid">'+data.map(c=>'<div class="card action" onclick="cityByName('+JSON.stringify(c.name)+')"><div class="icon">📍</div><b>'+esc(c.name)+'</b><div class="small">'+esc(c.region)+'</div></div>').join('')+'</div>';
}
function cityByName(name){
  const map={
    'Copiapó':'copiapo','Caldera':'caldera','Vallenar':'vallenar','Chañaral':'chanaral','Huasco':'huasco','Freirina':'freirina','Diego de Almagro':'diego','Tierra Amarilla':'tierra','Alto del Carmen':'alto'
  };
  city(map[name]||'copiapo');
}

sb.auth.onAuthStateChange((_event,session)=>{
  const el=document.getElementById('onlineStatus');
  if(session) el.innerHTML='☁️ <b>Conectado</b> · sesión iniciada';
  else if(el) el.innerHTML='☁️ <b>Conectado</b> · sin sesión';
  updateSessionUI(session);
});
checkOnline();
sb.auth.getSession().then(({data})=>{updateSessionUI(data.session); loadMyPosts();});


(function(){
  function counter(input){
    var el=document.querySelector('[data-counter-for="'+input.id+'"]');
    if(el) el.textContent=input.value.length+' caracteres';
  }
  document.addEventListener('click',function(e){
    var b=e.target.closest&&e.target.closest('.toggle-password');
    if(!b)return;
    var i=document.getElementById(b.dataset.target);
    if(!i)return;
    var show=i.type==='password';
    i.type=show?'text':'password';
    b.textContent=show?'🙈':'👁️';
    b.setAttribute('aria-label',show?'Ocultar contraseña':'Mostrar contraseña');
  });
  document.addEventListener('input',function(e){
    if(e.target&&e.target.matches&&e.target.matches('input[type="password"],input[type="text"]')){
      if(document.querySelector('[data-counter-for="'+e.target.id+'"]')) counter(e.target);
    }
  });
  document.querySelectorAll('.password-counter').forEach(function(el){
    var i=document.getElementById(el.dataset.counterFor); if(i) counter(i);
  });
})();
async function loadNotifications(){
  const box=document.getElementById('notificationsResults');
  if(!box) return;
  const {data:{user}}=await sb.auth.getUser();
  if(!user){ box.innerHTML='<div class="notice">🔐 Inicia sesión para ver tus notificaciones.</div>'; return; }
  box.innerHTML='<div class="notice">⏳ Cargando notificaciones…</div>';
  const {data,error}=await sb.from('notifications').select('id,type,title,message,post_id,business_submission_id,read_at,created_at').order('created_at',{ascending:false}).limit(50);
  if(error){ box.innerHTML='<div class="notice">⚠️ No se pudieron cargar las notificaciones.</div>'; return; }
  if(!data||!data.length){ box.innerHTML='<div class="notice">No tienes notificaciones nuevas.</div>'; return; }
  box.innerHTML=data.map(n=>'<div class="item" style="opacity:'+(n.read_at?'0.7':'1')+'"><div class="top"><h3>'+esc(n.title)+'</h3>'+(!n.read_at?'<span class="badge">Nueva</span>':'')+'</div><div class="meta">'+esc(n.message)+'<br><small>'+new Date(n.created_at).toLocaleString('es-CL')+'</small></div>'+(!n.read_at?'<button class="btn" style="margin-top:8px" onclick="markNotificationRead('+n.id+');this.parentElement.style.opacity=\"0.7\";this.remove()">Marcar como leída</button>':'')+'</div>').join('');
}
async function markNotificationRead(id){ await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',id); }

