# MascotaDatos — Publicaciones

## Estado actual (v27)
- Formularios de adopción, perdida y encontrada.
- Selección de ciudad desde Supabase.
- Autenticación real con Supabase.
- Fotografías almacenadas en bucket privado `pet-photos`.
- Avisos creados como `pendiente`.
- Moderación mediante políticas RLS.
- Publicación pública solo con estado `publicada`.
- Fotografías públicas servidas mediante URL temporal para avisos publicados.
- Reportes enviados a `post_reports`.
- El propietario puede consultar y eliminar sus propios avisos según RLS.

## Pendiente de validación
- Recorrido completo desde Android/teléfono.
- Pruebas de moderador con una cuenta que tenga los permisos correspondientes.
- Pruebas negativas de RLS/pgTAP y ejecución de la suite con `supabase test db`.
- Revisión final de privacidad, términos y publicación.

## Regla de seguridad
No mostrar públicamente teléfonos, correos o direcciones personales más allá de lo necesario. En perdidos/encontrados se recomienda contacto intermediado por la aplicación.
