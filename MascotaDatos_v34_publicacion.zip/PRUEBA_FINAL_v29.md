# MascotaDatos v29 — Checklist de prueba final

## Flujo principal
- [ ] Abrir la PWA en Android
- [ ] Crear cuenta
- [ ] Iniciar sesión
- [ ] Crear aviso de adopción
- [ ] Seleccionar ciudad
- [ ] Subir fotografía JPG/PNG/WebP
- [ ] Confirmar que el aviso queda pendiente
- [ ] Entrar como moderador
- [ ] Aprobar el aviso
- [ ] Comprobar que aparece en publicaciones públicas
- [ ] Comprobar que la fotografía se muestra
- [ ] Crear un reporte
- [ ] Revisar el reporte como moderador
- [ ] Cerrar sesión

## Seguridad
- [ ] Usuario normal no puede moderar
- [ ] Usuario normal no puede cambiar el estado de su aviso
- [ ] Usuario solo puede administrar sus propios avisos
- [ ] Fotografías pendientes/rechazadas no son públicas

## Antes de publicar
- [ ] Probar instalación/PWA en Android
- [ ] Revisar privacidad y términos
- [ ] Revisar datos de veterinarias/servicios
- [ ] Ejecutar pruebas RLS/pgTAP y obtener PASS
