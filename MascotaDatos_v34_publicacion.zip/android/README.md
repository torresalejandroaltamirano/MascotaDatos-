# MascotaDatos — preparación Android

Aplicación: MascotaDatos
Paquete sugerido: cl.mascotadatos.app
Nombre visible: MascotaDatos

La interfaz web está preparada como PWA y puede envolverse en Android con WebView/Capacitor.
Para la versión online real, el backend deberá usar HTTPS y la app necesitará permisos
solo cuando sean necesarios (por ejemplo, cámara/fotos o ubicación).

Importante: este paquete NO es todavía un APK instalable. Es la preparación técnica
para generar el APK/AAB en la siguiente etapa de compilación.
