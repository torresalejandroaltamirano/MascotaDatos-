# MascotaDatos — Plan de cierre

## Ya integrado
- PWA responsive e identidad visual.
- Backend Supabase.
- Cuentas reales.
- Publicaciones de adopción/perdida/encontrada.
- Fotos privadas.
- Moderación y reportes.
- Búsqueda de publicaciones publicadas.

## Próximos pasos
1. Prueba completa en Android.
2. Pruebas RLS/pgTAP y resultado `PASS`.
3. Revisión de privacidad y términos.
4. Revisión de datos de veterinarias y comercios.
5. Preparación del paquete final de publicación.
6. Revisión formal de la marca MascotaDatos en INAPI.
