# Integración online — MascotaDatos v16

Proyecto Supabase conectado:
- URL: https://dipqxifxrkujvfukcskg.supabase.co
- Se usa una publishable key en el cliente (no es una contraseña de base de datos).
- Las ciudades se leen desde la tabla `cities`.
- Las publicaciones de mascotas autenticadas se insertan en `pet_posts` con estado `pendiente`.
- RLS permanece activo.

## Seguridad
No incluir nunca la contraseña de Postgres en la aplicación.
La moderación debe publicar avisos cambiando su estado a `publicada`; los usuarios no pueden hacerlo directamente por las políticas actuales.
