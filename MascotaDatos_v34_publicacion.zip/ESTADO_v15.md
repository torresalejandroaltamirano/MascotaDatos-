# MascotaDatos v15 — estado

- Logo aprobado y diseño limpio.
- Veterinarias por ciudad.
- Insumos y locales por ciudad.
- Buscador.
- Mapas.
- Adopción.
- Perdidos y encontrados.
- Formularios de publicaciones.
- Seguridad, reportes, cuentas y publicaciones conectadas al backend; pendientes las pruebas finales en Android.
- PWA manifest + modo instalable/offline preparado.
- Estructura Android preparada.

Pendiente antes de publicación:
- Validación final del backend online.
- Validación final de cuentas reales.
- Almacenamiento seguro de fotos.
- Pruebas de moderación y flujo completo.
- Pruebas Android.
- Políticas y términos definitivos.
- Verificación final de datos.
- Revisión formal de marca.
- Generar y firmar APK/AAB.


## v32 — Estado
- Recuperación de contraseña visible en Mi cuenta.
- Ojo mostrar/ocultar contraseña y contador de caracteres en registro, inicio de sesión y cambio de contraseña.
- El enlace de recuperación usa la URL actual sin el hash de tokens.
- Bloqueo pendiente fuera del HTML: si el enlace de correo apunta a localhost:3000 y ese servidor no está ejecutándose, el navegador mostrará ERR_CONNECTION_REFUSED. Para recuperación real desde correo se necesita una URL pública/de despliegue incluida en los Redirect URLs de Supabase.
